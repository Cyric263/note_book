
The Zorin OS Linux Document Notes Bunddle
Dated 10/21/2016
Listed in order of Install Steps
==============================================


1. 20things.txt

2. PalSupeBeta600InstructionsforLinux
(note there is a new 700ish beta out)

3. SoundSetupLinuxandPal

4. YouTubeDownloade

5. FTPPhoneToZorinOS (android to Zornin

6. USB Image Maker - Usbs can easily crash.
Make an image of your usb when it is in perfect
condition.  Located Here:

Windows USB Imaging Software
http://www.alexpage.de/usb-image-tool/
